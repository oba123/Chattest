# Socket.IO chat example for Heroku

Config updated to run on heroku, and transport set to xhr-polling with a 20s timeout

You can see it in action at: http://socket-io-chat.herokuapp.com/

## Deploying

    heroku create -s cedar
    git push heroku master

Enjoy!
